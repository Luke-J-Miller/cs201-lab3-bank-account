[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=8012074&assignment_repo_type=AssignmentRepo)
# lab3

<img width="540" alt="lab 033" src="https://user-images.githubusercontent.com/106999018/173633450-58a1b5f2-528f-4764-99c3-5984b04fc403.png">
